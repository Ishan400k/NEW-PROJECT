import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  timestamp,
} from "drizzle-orm/pg-core";

// Stores every completed fitness quiz submission along with the
// computed personalized plan numbers (BMI, calories, macros, water).
export const quizResponses = pgTable("quiz_responses", {
  id: serial("id").primaryKey(),
  name: text("name"),
  email: text("email"),
  gender: text("gender").notNull(),
  age: integer("age").notNull(),
  heightCm: integer("height_cm").notNull(),
  weightKg: integer("weight_kg").notNull(),
  goal: text("goal").notNull(),
  activityLevel: text("activity_level").notNull(),
  dietPreference: text("diet_preference"),
  targetAreas: text("target_areas"),
  bmi: numeric("bmi", { precision: 5, scale: 1 }).notNull(),
  bmiCategory: text("bmi_category").notNull(),
  bmr: integer("bmr").notNull(),
  dailyCalories: integer("daily_calories").notNull(),
  proteinG: integer("protein_g").notNull(),
  carbsG: integer("carbs_g").notNull(),
  fatsG: integer("fats_g").notNull(),
  waterLiters: numeric("water_liters", { precision: 3, scale: 1 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Stores subscription / checkout attempts generated from the quiz funnel.
// First charge is 40 INR, then it renews at 129 INR / month.
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  quizResponseId: integer("quiz_response_id").references(
    () => quizResponses.id,
  ),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  plan: text("plan").notNull().default("monthly"),
  firstChargeInr: integer("first_charge_inr").notNull().default(40),
  recurringChargeInr: integer("recurring_charge_inr").notNull().default(129),
  status: text("status").notNull().default("active"),
  orderId: text("order_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
