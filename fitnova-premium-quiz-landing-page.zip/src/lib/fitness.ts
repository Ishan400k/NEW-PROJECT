export type Gender = "male" | "female" | "other";
export type Goal = "lose_weight" | "build_muscle" | "get_toned" | "improve_stamina";
export type ActivityLevel = "sedentary" | "light" | "moderate" | "active";

export interface QuizInput {
  gender: Gender;
  age: number;
  heightCm: number;
  weightKg: number;
  goal: Goal;
  activityLevel: ActivityLevel;
  dietPreference?: string;
  targetAreas?: string[];
}

export interface PlanResult {
  bmi: number;
  bmiCategory: string;
  bmr: number;
  dailyCalories: number;
  proteinG: number;
  carbsG: number;
  fatsG: number;
  waterLiters: number;
}

const activityMultiplier: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
};

const goalCalorieAdjustment: Record<Goal, number> = {
  lose_weight: -400,
  build_muscle: 300,
  get_toned: -150,
  improve_stamina: 100,
};

export function computePlan(input: QuizInput): PlanResult {
  const { gender, age, heightCm, weightKg, goal, activityLevel } = input;

  const heightM = heightCm / 100;
  const bmiRaw = weightKg / (heightM * heightM);
  const bmi = Math.round(bmiRaw * 10) / 10;

  let bmiCategory = "Normal";
  if (bmi < 18.5) bmiCategory = "Underweight";
  else if (bmi >= 18.5 && bmi < 25) bmiCategory = "Normal";
  else if (bmi >= 25 && bmi < 30) bmiCategory = "Overweight";
  else bmiCategory = "Obese";

  // Mifflin-St Jeor Equation
  const bmrBase = 10 * weightKg + 6.25 * heightCm - 5 * age;
  const bmr = Math.round(gender === "female" ? bmrBase - 161 : bmrBase + 5);

  const maintenance = bmr * activityMultiplier[activityLevel];
  const dailyCalories = Math.round((maintenance + goalCalorieAdjustment[goal]) / 10) * 10;

  const proteinPerKg = goal === "build_muscle" ? 2.0 : goal === "get_toned" ? 1.8 : 1.6;
  const proteinG = Math.round(weightKg * proteinPerKg);
  const fatsG = Math.round((dailyCalories * 0.25) / 9);
  const proteinCalories = proteinG * 4;
  const fatCalories = fatsG * 9;
  const carbsG = Math.max(0, Math.round((dailyCalories - proteinCalories - fatCalories) / 4));

  const waterLiters = Math.round(((weightKg * 0.035) + (activityLevel === "active" ? 0.5 : 0.2)) * 10) / 10;

  return { bmi, bmiCategory, bmr, dailyCalories, proteinG, carbsG, fatsG, waterLiters };
}

export const goalLabels: Record<Goal, string> = {
  lose_weight: "Lose Weight",
  build_muscle: "Build Muscle",
  get_toned: "Get Toned",
  improve_stamina: "Improve Stamina",
};

export const activityLabels: Record<ActivityLevel, string> = {
  sedentary: "Sedentary (little to no exercise)",
  light: "Lightly Active (1-3 days/week)",
  moderate: "Moderately Active (3-5 days/week)",
  active: "Very Active (6-7 days/week)",
};
