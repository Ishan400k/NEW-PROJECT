import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "FitNova — Your Personalized Fitness Coach",
  description:
    "Get a custom workout plan, meal plan, and daily guidance designed just for your body and your goals. Take the free 2-minute quiz and start your transformation today for just ₹40.",
  keywords: [
    "fitness app",
    "personalized workout plan",
    "meal plan",
    "fitness quiz",
    "FitNova",
    "weight loss",
    "muscle building",
  ],
  openGraph: {
    title: "FitNova — Your Personalized Fitness Coach",
    description:
      "Take the free quiz and get a custom workout & meal plan built for your body and goals.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="bg-[#07080a] text-white antialiased selection:bg-[#7ef542] selection:text-black">
        {children}
      </body>
    </html>
  );
}
