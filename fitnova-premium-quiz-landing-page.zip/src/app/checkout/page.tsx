import type { Metadata } from "next";
import { Suspense } from "react";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";

export const metadata: Metadata = {
  title: "Checkout — FitNova",
  description: "Complete your FitNova subscription — ₹40 for the first month, then ₹129/month.",
};

export default function CheckoutPage() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#07080a]">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-30" />
      <div className="pointer-events-none absolute -left-40 top-0 h-96 w-96 animate-float-slow rounded-full bg-brand-500/15 blur-[120px]" />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 animate-float rounded-full bg-emerald-400/10 blur-[120px]" />
      <Suspense fallback={<div className="grid min-h-screen place-items-center text-white/40">Loading checkout…</div>}>
        <CheckoutForm />
      </Suspense>
    </main>
  );
}
