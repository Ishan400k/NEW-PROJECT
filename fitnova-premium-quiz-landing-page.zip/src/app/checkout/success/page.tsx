import type { Metadata } from "next";
import { Suspense } from "react";
import { SuccessView } from "@/components/checkout/SuccessView";

export const metadata: Metadata = {
  title: "You're In! — FitNova",
  description: "Your FitNova subscription is confirmed.",
};

export default function CheckoutSuccessPage() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#07080a]">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-30" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 animate-float-slow rounded-full bg-brand-500/15 blur-[120px]" />
      <Suspense fallback={<div className="grid min-h-screen place-items-center text-white/40">Loading…</div>}>
        <SuccessView />
      </Suspense>
    </main>
  );
}
