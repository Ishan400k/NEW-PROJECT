import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { NextRequest } from "next/server";
import { randomBytes } from "crypto";

export const dynamic = "force-dynamic";

function generateOrderId() {
  return `FN-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = typeof body.name === "string" ? body.name.trim().slice(0, 120) : "";
    const email = typeof body.email === "string" ? body.email.trim().slice(0, 160) : "";
    const phone = typeof body.phone === "string" ? body.phone.trim().slice(0, 20) : null;
    const quizResponseId = Number.isFinite(Number(body.quizResponseId)) ? Number(body.quizResponseId) : null;

    if (!name || name.length < 2) {
      return Response.json({ error: "Please enter your full name." }, { status: 400 });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      return Response.json({ error: "Please enter a valid email address." }, { status: 400 });
    }

    const orderId = generateOrderId();

    const [row] = await db
      .insert(subscriptions)
      .values({
        quizResponseId: quizResponseId ?? undefined,
        name,
        email,
        phone,
        plan: "monthly",
        firstChargeInr: 40,
        recurringChargeInr: 129,
        status: "active",
        orderId,
      })
      .returning({ id: subscriptions.id, orderId: subscriptions.orderId });

    return Response.json({ id: row.id, orderId: row.orderId });
  } catch (err) {
    console.error("Subscription failed", err);
    return Response.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
