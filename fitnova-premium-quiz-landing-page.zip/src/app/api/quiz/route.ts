import { db } from "@/db";
import { quizResponses } from "@/db/schema";
import { computePlan, type ActivityLevel, type Gender, type Goal } from "@/lib/fitness";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

const genders: Gender[] = ["male", "female", "other"];
const goals: Goal[] = ["lose_weight", "build_muscle", "get_toned", "improve_stamina"];
const activityLevels: ActivityLevel[] = ["sedentary", "light", "moderate", "active"];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const gender = body.gender as Gender;
    const age = Number(body.age);
    const heightCm = Number(body.heightCm);
    const weightKg = Number(body.weightKg);
    const goal = body.goal as Goal;
    const activityLevel = body.activityLevel as ActivityLevel;
    const dietPreference = typeof body.dietPreference === "string" ? body.dietPreference : null;
    const targetAreas = Array.isArray(body.targetAreas) ? body.targetAreas.join(",") : null;
    const name = typeof body.name === "string" ? body.name.slice(0, 120) : null;
    const email = typeof body.email === "string" ? body.email.slice(0, 160) : null;

    if (!genders.includes(gender) || !goals.includes(goal) || !activityLevels.includes(activityLevel)) {
      return Response.json({ error: "Invalid selection." }, { status: 400 });
    }
    if (!Number.isFinite(age) || age < 12 || age > 90) {
      return Response.json({ error: "Please enter a valid age between 12 and 90." }, { status: 400 });
    }
    if (!Number.isFinite(heightCm) || heightCm < 100 || heightCm > 230) {
      return Response.json({ error: "Please enter a valid height in centimeters." }, { status: 400 });
    }
    if (!Number.isFinite(weightKg) || weightKg < 30 || weightKg > 250) {
      return Response.json({ error: "Please enter a valid weight in kilograms." }, { status: 400 });
    }

    const plan = computePlan({ gender, age, heightCm, weightKg, goal, activityLevel });

    const [row] = await db
      .insert(quizResponses)
      .values({
        name,
        email,
        gender,
        age,
        heightCm,
        weightKg,
        goal,
        activityLevel,
        dietPreference,
        targetAreas,
        bmi: plan.bmi.toString(),
        bmiCategory: plan.bmiCategory,
        bmr: plan.bmr,
        dailyCalories: plan.dailyCalories,
        proteinG: plan.proteinG,
        carbsG: plan.carbsG,
        fatsG: plan.fatsG,
        waterLiters: plan.waterLiters.toString(),
      })
      .returning({ id: quizResponses.id });

    return Response.json({ id: row.id, plan });
  } catch (err) {
    console.error("Quiz submission failed", err);
    return Response.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
