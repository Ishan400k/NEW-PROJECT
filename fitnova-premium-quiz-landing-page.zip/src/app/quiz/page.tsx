import type { Metadata } from "next";
import { QuizFlow } from "@/components/quiz/QuizFlow";

export const metadata: Metadata = {
  title: "Take the Free Fitness Quiz — FitNova",
  description:
    "Answer a few quick questions and get your personalized workout plan, meal plan and daily calorie targets in under 2 minutes.",
};

export default function QuizPage() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#07080a]">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-30" />
      <div className="pointer-events-none absolute -left-40 top-0 h-96 w-96 animate-float-slow rounded-full bg-brand-500/15 blur-[120px]" />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 animate-float rounded-full bg-emerald-400/10 blur-[120px]" />
      <QuizFlow />
    </main>
  );
}
