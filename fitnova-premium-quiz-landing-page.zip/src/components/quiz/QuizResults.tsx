"use client";

import { motion } from "framer-motion";
import { ArrowRight, Droplets, Flame, Beef, Wheat, Sparkles, ShieldCheck } from "lucide-react";

interface PlanResult {
  bmi: number;
  bmiCategory: string;
  bmr: number;
  dailyCalories: number;
  proteinG: number;
  carbsG: number;
  fatsG: number;
  waterLiters: number;
}

export function QuizResults({
  plan,
  onCheckout,
}: {
  plan: PlanResult;
  quizResponseId: number;
  onCheckout: () => void;
}) {
  const bmiPercent = Math.min(100, Math.max(0, ((plan.bmi - 15) / (35 - 15)) * 100));

  const macros = [
    { icon: Beef, label: "Protein", value: `${plan.proteinG}g`, color: "#7ef542" },
    { icon: Wheat, label: "Carbs", value: `${plan.carbsG}g`, color: "#facc15" },
    { icon: Flame, label: "Fats", value: `${plan.fatsG}g`, color: "#f97316" },
    { icon: Droplets, label: "Water", value: `${plan.waterLiters}L`, color: "#38bdf8" },
  ];

  return (
    <div className="relative mx-auto flex min-h-screen max-w-3xl flex-col px-4 py-12 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="text-center"
      >
        <span className="mx-auto inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-400/10 px-4 py-1.5 text-xs font-semibold text-brand-300">
          <Sparkles className="h-3.5 w-3.5" />
          Your plan is ready
        </span>
        <h1 className="mt-5 text-3xl font-extrabold text-white sm:text-4xl">
          Here's your <span className="text-gradient">personalized plan</span>
        </h1>
        <p className="mx-auto mt-3 max-w-md text-sm text-white/50">
          Based on your answers, we've calculated your ideal daily targets to hit your goal.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        className="glass mt-10 rounded-3xl p-6 sm:p-8"
      >
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-white/40">
              Body Mass Index
            </p>
            <div className="mt-3 flex items-end gap-3">
              <span className="text-5xl font-extrabold text-white">{plan.bmi}</span>
              <span className="mb-1.5 rounded-full bg-brand-400/15 px-3 py-1 text-xs font-semibold text-brand-400">
                {plan.bmiCategory}
              </span>
            </div>
            <div className="relative mt-4 h-2 w-full overflow-hidden rounded-full bg-gradient-to-r from-sky-400 via-brand-400 to-orange-500">
              <div
                className="absolute top-1/2 h-4 w-4 -translate-y-1/2 rounded-full border-2 border-black bg-white shadow-lg transition-all duration-700"
                style={{ left: `calc(${bmiPercent}% - 8px)` }}
              />
            </div>
            <div className="mt-2 flex justify-between text-[10px] text-white/30">
              <span>15</span>
              <span>25</span>
              <span>35</span>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-white/40">
              Daily Calorie Target
            </p>
            <div className="mt-3 flex items-end gap-2">
              <span className="text-5xl font-extrabold text-white">{plan.dailyCalories}</span>
              <span className="mb-1.5 text-sm text-white/40">kcal / day</span>
            </div>
            <p className="mt-3 text-xs text-white/40">
              Base metabolic rate (BMR): <span className="text-white/70">{plan.bmr} kcal</span>
            </p>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {macros.map((m, i) => (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }}
              className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 text-center"
            >
              <m.icon className="mx-auto h-5 w-5" style={{ color: m.color }} />
              <p className="mt-2 text-lg font-bold text-white">{m.value}</p>
              <p className="text-[11px] text-white/40">{m.label}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.45 }}
        className="mt-10 rounded-3xl border border-brand-400/20 bg-brand-400/[0.04] p-6 text-center sm:p-8"
      >
        <p className="text-sm font-semibold text-white">
          Unlock your full workout & meal plan, live dashboard, and daily reminders.
        </p>
        <div className="mt-5 flex flex-col items-center justify-center gap-3">
          <button
            onClick={onCheckout}
            className="group inline-flex items-center gap-2 rounded-full bg-brand-400 px-8 py-4 text-base font-semibold text-black shadow-[0_0_35px_rgba(126,245,66,0.35)] transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_50px_rgba(126,245,66,0.55)] active:scale-95"
          >
            Unlock My Plan for ₹40
            <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
          </button>
          <p className="inline-flex items-center gap-1.5 text-xs text-white/40">
            <ShieldCheck className="h-3.5 w-3.5 text-brand-400" />
            ₹40 today, then ₹129/month · Cancel anytime
          </p>
        </div>
      </motion.div>
    </div>
  );
}
