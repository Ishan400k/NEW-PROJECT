"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Zap,
  ArrowLeft,
  ArrowRight,
  User,
  Users,
  UserRound,
  Minus,
  Plus,
  Flame,
  Trophy,
  Sparkles,
  HeartPulse,
  Sofa,
  Footprints,
  Bike,
  Salad,
  Beef,
  Leaf,
  Egg,
  Loader2,
} from "lucide-react";
import type { ActivityLevel, Gender, Goal } from "@/lib/fitness";
import { QuizResults } from "@/components/quiz/QuizResults";

interface FormState {
  gender: Gender | null;
  age: number;
  heightCm: number;
  weightKg: number;
  goal: Goal | null;
  activityLevel: ActivityLevel | null;
  dietPreference: string | null;
}

const initialState: FormState = {
  gender: null,
  age: 25,
  heightCm: 170,
  weightKg: 70,
  goal: null,
  activityLevel: null,
  dietPreference: null,
};

const TOTAL_STEPS = 7;

export function QuizFlow() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [direction, setDirection] = useState(1);
  const [form, setForm] = useState<FormState>(initialState);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    id: number;
    plan: {
      bmi: number;
      bmiCategory: string;
      bmr: number;
      dailyCalories: number;
      proteinG: number;
      carbsG: number;
      fatsG: number;
      waterLiters: number;
    };
  } | null>(null);

  const canProceed = useMemo(() => {
    switch (step) {
      case 1:
        return form.gender !== null;
      case 2:
        return form.age >= 12 && form.age <= 90;
      case 3:
        return form.heightCm >= 100 && form.heightCm <= 230;
      case 4:
        return form.weightKg >= 30 && form.weightKg <= 250;
      case 5:
        return form.goal !== null;
      case 6:
        return form.activityLevel !== null;
      case 7:
        return form.dietPreference !== null;
      default:
        return false;
    }
  }, [step, form]);

  function goNext() {
    if (!canProceed) return;
    setDirection(1);
    if (step < TOTAL_STEPS) {
      setStep((s) => s + 1);
    } else {
      submitQuiz();
    }
  }

  function goBack() {
    setDirection(-1);
    setStep((s) => Math.max(1, s - 1));
  }

  async function submitQuiz() {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error ?? "Something went wrong. Please try again.");
      }
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  }

  if (result) {
    return (
      <QuizResults
        plan={result.plan}
        quizResponseId={result.id}
        onCheckout={() => router.push(`/checkout?quizId=${result.id}`)}
      />
    );
  }

  const progress = Math.round(((step - 1) / TOTAL_STEPS) * 100);

  return (
    <div className="relative mx-auto flex min-h-screen max-w-2xl flex-col px-4 py-8 sm:px-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <a href="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-700 text-black">
            <Zap className="h-4 w-4" strokeWidth={2.5} />
          </span>
          <span className="text-base font-bold text-white">FitNova</span>
        </a>
        <span className="text-xs font-medium text-white/40">
          Step {step} of {TOTAL_STEPS}
        </span>
      </div>

      {/* Progress bar */}
      <div className="mt-5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full bg-gradient-to-r from-brand-300 to-brand-500 transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Card */}
      <div className="glass relative mt-8 flex flex-1 flex-col overflow-hidden rounded-3xl p-6 sm:p-10">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={step}
            custom={direction}
            initial={{ opacity: 0, x: direction * 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -40 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-1 flex-col"
          >
            {step === 1 && <GenderStep value={form.gender} onChange={(gender) => setForm((f) => ({ ...f, gender }))} />}
            {step === 2 && <NumberStep
              title="How old are you?"
              subtitle="This helps us calculate your metabolic rate accurately."
              value={form.age}
              unit="years"
              min={12}
              max={90}
              onChange={(age) => setForm((f) => ({ ...f, age }))}
            />}
            {step === 3 && <NumberStep
              title="What's your height?"
              subtitle="Enter your height in centimeters."
              value={form.heightCm}
              unit="cm"
              min={100}
              max={230}
              onChange={(heightCm) => setForm((f) => ({ ...f, heightCm }))}
            />}
            {step === 4 && <NumberStep
              title="What's your current weight?"
              subtitle="Enter your weight in kilograms."
              value={form.weightKg}
              unit="kg"
              min={30}
              max={250}
              onChange={(weightKg) => setForm((f) => ({ ...f, weightKg }))}
            />}
            {step === 5 && <GoalStep value={form.goal} onChange={(goal) => setForm((f) => ({ ...f, goal }))} />}
            {step === 6 && <ActivityStep value={form.activityLevel} onChange={(activityLevel) => setForm((f) => ({ ...f, activityLevel }))} />}
            {step === 7 && <DietStep value={form.dietPreference} onChange={(dietPreference) => setForm((f) => ({ ...f, dietPreference }))} />}
          </motion.div>
        </AnimatePresence>

        {error && (
          <p className="mt-4 rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-400">{error}</p>
        )}

        {/* Nav buttons */}
        <div className="mt-8 flex items-center justify-between gap-4">
          <button
            onClick={goBack}
            disabled={step === 1 || submitting}
            className="inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-medium text-white/50 transition-colors hover:text-white disabled:pointer-events-none disabled:opacity-0"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>
          <button
            onClick={goNext}
            disabled={!canProceed || submitting}
            className="group inline-flex items-center gap-2 rounded-full bg-brand-400 px-7 py-3.5 text-sm font-semibold text-black shadow-[0_0_25px_rgba(126,245,66,0.3)] transition-all duration-300 hover:scale-105 hover:shadow-[0_0_35px_rgba(126,245,66,0.5)] active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Building your plan...
              </>
            ) : step === TOTAL_STEPS ? (
              <>
                See My Results
                <Sparkles className="h-4 w-4" />
              </>
            ) : (
              <>
                Continue
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </>
            )}
          </button>
        </div>
      </div>

      <p className="mt-6 text-center text-xs text-white/30">
        Your answers are used only to personalize your plan. 100% free, no credit card required.
      </p>
    </div>
  );
}

function StepHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-8">
      <h1 className="text-2xl font-extrabold text-white sm:text-3xl">{title}</h1>
      <p className="mt-2 text-sm text-white/45">{subtitle}</p>
    </div>
  );
}

function OptionButton({
  selected,
  onClick,
  icon: Icon,
  label,
  desc,
}: {
  selected: boolean;
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  desc?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`group flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition-all duration-250 ${
        selected
          ? "border-brand-400/60 bg-brand-400/10 shadow-[0_0_25px_rgba(126,245,66,0.15)]"
          : "border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]"
      }`}
    >
      <span
        className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl transition-colors duration-250 ${
          selected ? "bg-brand-400 text-black" : "bg-white/5 text-white/60 group-hover:text-white"
        }`}
      >
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block font-semibold text-white">{label}</span>
        {desc && <span className="block text-xs text-white/40">{desc}</span>}
      </span>
      <span
        className={`ml-auto h-5 w-5 shrink-0 rounded-full border-2 transition-colors ${
          selected ? "border-brand-400 bg-brand-400" : "border-white/20"
        }`}
      />
    </button>
  );
}

function GenderStep({ value, onChange }: { value: Gender | null; onChange: (g: Gender) => void }) {
  return (
    <div>
      <StepHeader title="What's your gender?" subtitle="We use this to accurately calculate your metabolic rate." />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <OptionButton selected={value === "male"} onClick={() => onChange("male")} icon={User} label="Male" />
        <OptionButton selected={value === "female"} onClick={() => onChange("female")} icon={UserRound} label="Female" />
        <OptionButton selected={value === "other"} onClick={() => onChange("other")} icon={Users} label="Other" />
      </div>
    </div>
  );
}

function NumberStep({
  title,
  subtitle,
  value,
  unit,
  min,
  max,
  onChange,
}: {
  title: string;
  subtitle: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  const step = unit === "years" ? 1 : 1;
  return (
    <div>
      <StepHeader title={title} subtitle={subtitle} />
      <div className="flex flex-col items-center gap-6 py-6">
        <div className="flex items-center gap-6">
          <button
            onClick={() => onChange(Math.max(min, value - step))}
            className="grid h-12 w-12 place-items-center rounded-full border border-white/15 text-white transition-colors hover:border-brand-400 hover:text-brand-400"
            aria-label="Decrease"
          >
            <Minus className="h-5 w-5" />
          </button>
          <div className="text-center">
            <span className="text-5xl font-extrabold text-white tabular-nums">{value}</span>
            <span className="ml-2 text-lg font-medium text-white/40">{unit}</span>
          </div>
          <button
            onClick={() => onChange(Math.min(max, value + step))}
            className="grid h-12 w-12 place-items-center rounded-full border border-white/15 text-white transition-colors hover:border-brand-400 hover:text-brand-400"
            aria-label="Increase"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="h-2 w-full max-w-sm cursor-pointer appearance-none rounded-full bg-white/10 accent-[#7ef542]"
        />
        <div className="flex w-full max-w-sm justify-between text-xs text-white/30">
          <span>{min}</span>
          <span>{max}</span>
        </div>
      </div>
    </div>
  );
}

function GoalStep({ value, onChange }: { value: Goal | null; onChange: (g: Goal) => void }) {
  const options: { id: Goal; icon: React.ComponentType<{ className?: string }>; label: string; desc: string }[] = [
    { id: "lose_weight", icon: Flame, label: "Lose Weight", desc: "Burn fat & feel lighter" },
    { id: "build_muscle", icon: Trophy, label: "Build Muscle", desc: "Gain lean mass & strength" },
    { id: "get_toned", icon: Sparkles, label: "Get Toned", desc: "Define & sculpt your body" },
    { id: "improve_stamina", icon: HeartPulse, label: "Improve Stamina", desc: "Boost endurance & energy" },
  ];
  return (
    <div>
      <StepHeader title="What's your primary goal?" subtitle="We'll tailor your plan around this." />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {options.map((opt) => (
          <OptionButton
            key={opt.id}
            selected={value === opt.id}
            onClick={() => onChange(opt.id)}
            icon={opt.icon}
            label={opt.label}
            desc={opt.desc}
          />
        ))}
      </div>
    </div>
  );
}

function ActivityStep({
  value,
  onChange,
}: {
  value: ActivityLevel | null;
  onChange: (a: ActivityLevel) => void;
}) {
  const options: { id: ActivityLevel; icon: React.ComponentType<{ className?: string }>; label: string; desc: string }[] = [
    { id: "sedentary", icon: Sofa, label: "Sedentary", desc: "Little to no exercise" },
    { id: "light", icon: Footprints, label: "Lightly Active", desc: "1-3 workouts / week" },
    { id: "moderate", icon: Bike, label: "Moderately Active", desc: "3-5 workouts / week" },
    { id: "active", icon: Zap, label: "Very Active", desc: "6-7 workouts / week" },
  ];
  return (
    <div>
      <StepHeader title="How active are you?" subtitle="This helps us calculate your daily calorie needs." />
      <div className="flex flex-col gap-3">
        {options.map((opt) => (
          <OptionButton
            key={opt.id}
            selected={value === opt.id}
            onClick={() => onChange(opt.id)}
            icon={opt.icon}
            label={opt.label}
            desc={opt.desc}
          />
        ))}
      </div>
    </div>
  );
}

function DietStep({ value, onChange }: { value: string | null; onChange: (d: string) => void }) {
  const options = [
    { id: "vegetarian", icon: Salad, label: "Vegetarian", desc: "Plant-based meals" },
    { id: "non_vegetarian", icon: Beef, label: "Non-Vegetarian", desc: "Meat, fish & everything" },
    { id: "vegan", icon: Leaf, label: "Vegan", desc: "No animal products" },
    { id: "eggetarian", icon: Egg, label: "Eggetarian", desc: "Veg + eggs" },
  ];
  return (
    <div>
      <StepHeader title="Any dietary preference?" subtitle="Your meal plan will be built around this." />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {options.map((opt) => (
          <OptionButton
            key={opt.id}
            selected={value === opt.id}
            onClick={() => onChange(opt.id)}
            icon={opt.icon}
            label={opt.label}
            desc={opt.desc}
          />
        ))}
      </div>
    </div>
  );
}
