import { Check, ShieldCheck, Lock, BadgeCheck, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const included = [
  "Full personalized workout plan",
  "Custom daily meal plan & macros",
  "Live progress dashboard",
  "Smart meal & workout reminders",
  "Weekly plan re-calibration",
  "Cancel anytime, no lock-in",
];

export function Pricing() {
  return (
    <section id="pricing" className="relative bg-[#0a0b0d] py-24">
      <div className="pointer-events-none absolute left-1/2 top-0 h-96 w-[40rem] -translate-x-1/2 rounded-full bg-brand-500/10 blur-[130px]" />
      <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
            Simple pricing
          </p>
          <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            Start your transformation <span className="text-gradient">today.</span>
          </h2>
          <p className="mt-4 text-white/55">
            Take the quiz, unlock your custom plan, and try FitNova for your first month at a
            special price.
          </p>
        </Reveal>

        <Reveal delay={120} direction="scale">
          <div className="relative mt-14 overflow-hidden rounded-[2rem] border border-brand-400/25 bg-gradient-to-b from-white/[0.04] to-transparent p-1 shadow-[0_0_80px_rgba(126,245,66,0.08)]">
            <div className="rounded-[1.85rem] bg-[#0c0e0c] p-8 sm:p-10">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-400/15 px-3 py-1 text-xs font-semibold text-brand-400">
                    <BadgeCheck className="h-3.5 w-3.5" /> Most popular
                  </span>
                  <h3 className="mt-3 text-2xl font-bold text-white">FitNova Personalized Plan</h3>
                  <p className="mt-1 text-sm text-white/45">
                    Everything you need to reach your fitness goal — designed just for you.
                  </p>
                </div>
              </div>

              <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div className="rounded-2xl border border-brand-400/30 bg-brand-400/5 p-5">
                  <p className="text-xs font-medium uppercase tracking-wide text-white/40">First month</p>
                  <p className="mt-2 text-4xl font-extrabold text-brand-400">
                    ₹40
                    <span className="text-sm font-medium text-white/40"> one-time</span>
                  </p>
                  <p className="mt-1 text-xs text-white/40">Unlock your full personalized plan</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                  <p className="text-xs font-medium uppercase tracking-wide text-white/40">From 2nd month</p>
                  <p className="mt-2 text-4xl font-extrabold text-white">
                    ₹129
                    <span className="text-sm font-medium text-white/40"> /month</span>
                  </p>
                  <p className="mt-1 text-xs text-white/40">Auto-renews monthly, cancel anytime</p>
                </div>
              </div>

              <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {included.map((item) => (
                  <li key={item} className="flex items-center gap-2.5 text-sm text-white/70">
                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand-400/15 text-brand-400">
                      <Check className="h-3 w-3" strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>

              <a
                href="/quiz"
                className="group mt-9 flex w-full items-center justify-center gap-2 rounded-full bg-brand-400 py-4 text-base font-semibold text-black shadow-[0_0_35px_rgba(126,245,66,0.35)] transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_50px_rgba(126,245,66,0.55)] active:scale-95"
              >
                <Lock className="h-4 w-4" />
                Get Started Now
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <p className="mt-3 text-center text-xs text-white/35">
                Today: ₹40 &nbsp;•&nbsp; Next month: ₹129/month
              </p>

              <div className="mt-7 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 border-t border-white/8 pt-6 text-xs text-white/40">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-brand-400" /> Cancel anytime
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Lock className="h-4 w-4 text-brand-400" /> Secure payment
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <BadgeCheck className="h-4 w-4 text-brand-400" /> No hidden charges
                </span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
