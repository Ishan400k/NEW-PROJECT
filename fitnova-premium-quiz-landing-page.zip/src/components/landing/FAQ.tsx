"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const faqs = [
  {
    q: "How does the free quiz work?",
    a: "You answer 25+ simple questions about your gender, age, height, weight, goals and activity level. Our system instantly calculates your BMI, BMR, daily calorie target and macros to build your personalized plan.",
  },
  {
    q: "Why is the first month only ₹40?",
    a: "We want you to experience the full personalized plan, meal guidance and dashboard risk-free before committing. ₹40 unlocks your complete first month of access.",
  },
  {
    q: "What happens after the first month?",
    a: "Your subscription automatically renews at ₹129/month so you keep getting updated plans, reminders and progress tracking. You can cancel anytime from your account before renewal with zero hidden fees.",
  },
  {
    q: "Can I cancel my subscription anytime?",
    a: "Yes. There's no lock-in contract. You can cancel anytime from your dashboard and you won't be charged for the next cycle.",
  },
  {
    q: "Is the plan suitable for beginners?",
    a: "Absolutely. Your workout intensity and calorie targets are tailored to your current activity level, so whether you're a complete beginner or advanced, the plan adapts to you.",
  },
  {
    q: "Do I need a gym membership?",
    a: "No. During the quiz you can tell us your available equipment and we'll tailor home or gym-based workouts accordingly.",
  },
  {
    q: "Is my data safe?",
    a: "Yes, all your personal and payment information is encrypted and never sold to third parties. We only use it to personalize your fitness experience.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative bg-[#07080a] py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
            FAQ
          </p>
          <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            Frequently asked <span className="text-gradient">questions.</span>
          </h2>
        </Reveal>

        <div className="mt-12 space-y-3">
          {faqs.map((faq, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={faq.q} delay={i * 60}>
                <div
                  className={`overflow-hidden rounded-2xl border transition-colors duration-300 ${
                    isOpen ? "border-brand-400/30 bg-brand-400/[0.04]" : "border-white/8 bg-white/[0.02]"
                  }`}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                  >
                    <span className="font-semibold text-white">{faq.q}</span>
                    <ChevronDown
                      className={`h-5 w-5 shrink-0 text-brand-400 transition-transform duration-300 ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  <div
                    className={`grid transition-all duration-300 ease-out ${
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="px-6 pb-5 text-sm leading-relaxed text-white/55">{faq.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
