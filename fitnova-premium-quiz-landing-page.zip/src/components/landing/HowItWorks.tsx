import { ArrowRight, User, Calendar, Ruler, Weight, Target } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const steps = [
  { icon: User, title: "Gender", desc: "Select your gender" },
  { icon: Calendar, title: "Age", desc: "Enter your age" },
  { icon: Ruler, title: "Height", desc: "Enter your height" },
  { icon: Weight, title: "Weight", desc: "Enter your weight" },
  { icon: Target, title: "Goal", desc: "Select your goal" },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="relative bg-[#07080a] py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-[280px_1fr] lg:gap-16">
          <Reveal direction="left">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
                How it works
              </p>
              <h2 className="mt-3 text-3xl font-extrabold leading-tight text-white sm:text-4xl">
                Simple Quiz.
                <br />
                <span className="text-gradient">Powerful Results.</span>
              </h2>
              <p className="mt-4 text-white/55">
                Answer a few simple questions and our system will create the perfect plan for
                you — no guesswork, no generic templates.
              </p>
            </div>
          </Reveal>

          <div className="flex flex-col gap-6">
            <div className="flex flex-wrap items-center gap-3 sm:flex-nowrap sm:gap-2">
              {steps.map((step, i) => (
                <Reveal key={step.title} delay={i * 90} className="flex items-center gap-2">
                  <div className="group flex flex-col items-center gap-2 text-center">
                    <div className="grid h-16 w-16 place-items-center rounded-2xl border border-white/10 bg-white/[0.03] text-brand-300 transition-all duration-300 group-hover:-translate-y-1.5 group-hover:border-brand-400/50 group-hover:bg-brand-400/10 group-hover:shadow-[0_0_25px_rgba(126,245,66,0.25)]">
                      <step.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">
                        {i + 1}. {step.title}
                      </p>
                      <p className="w-24 text-[11px] text-white/40">{step.desc}</p>
                    </div>
                  </div>
                  {i < steps.length - 1 && (
                    <ArrowRight className="hidden h-4 w-4 shrink-0 text-white/20 sm:block" />
                  )}
                </Reveal>
              ))}
            </div>

            <Reveal delay={500}>
              <div className="glass flex flex-col items-start justify-between gap-4 rounded-2xl border-brand-400/20 p-6 sm:flex-row sm:items-center">
                <div>
                  <p className="text-2xl font-extrabold text-brand-400">25+ Questions</p>
                  <p className="text-sm text-white/50">Personalized entirely for you</p>
                </div>
                <a
                  href="/quiz"
                  className="inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-white/20"
                >
                  Take the quiz
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
