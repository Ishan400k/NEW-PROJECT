import Image from "next/image";
import { Flame, Droplets, Dumbbell, Footprints, CheckCircle2, Mail } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const planStats = [
  { label: "BMI", value: "22.4", note: "Normal" },
  { label: "BMR", value: "1870 kcal" },
  { label: "Daily Calories", value: "2100 kcal" },
  { label: "Protein", value: "142 g" },
  { label: "Carbs", value: "240 g" },
  { label: "Water Intake", value: "3.2 L" },
];

const todaysPlan = [
  { time: "07:30 AM", title: "Workout — Chest & Triceps", icon: Dumbbell },
  { time: "08:30 AM", title: "Breakfast — Oats with Fruits", icon: Flame },
  { time: "01:00 PM", title: "Lunch — Chicken, Rice, Salad", icon: CheckCircle2 },
  { time: "07:30 PM", title: "Dinner — Paneer, Roti, Veggies", icon: CheckCircle2 },
];

export function ProductShowcase() {
  return (
    <section id="results" className="relative bg-[#07080a] py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
            Inside FitNova
          </p>
          <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            Your plan, meals & progress —{" "}
            <span className="text-gradient">all in one dashboard.</span>
          </h2>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Plan summary */}
          <Reveal direction="left" delay={80}>
            <div className="glass h-full rounded-3xl p-6">
              <h3 className="text-sm font-semibold text-white/80">Your Plan Summary</h3>
              <div className="mt-5 space-y-3">
                {planStats.map((stat) => (
                  <div key={stat.label} className="flex items-center justify-between border-b border-white/5 pb-3 last:border-0">
                    <span className="text-sm text-white/45">{stat.label}</span>
                    <span className="text-sm font-semibold text-white">
                      {stat.value}
                      {stat.note && <span className="ml-1.5 text-xs text-brand-400">{stat.note}</span>}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Meal + workout preview */}
          <Reveal delay={160}>
            <div className="flex h-full flex-col gap-6">
              <div className="glass overflow-hidden rounded-3xl p-6">
                <p className="text-xs font-semibold uppercase tracking-wide text-brand-400">
                  Meal Plan Preview
                </p>
                <p className="mt-1 text-sm font-semibold text-white">Day 1 — Breakfast</p>
                <div className="mt-4 flex gap-4">
                  <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl">
                    <Image src="/images/meal-preview.jpg" alt="Oats with fruits and protein" fill className="object-cover" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Oats with Fruits, Nuts & Whey Protein</p>
                    <p className="mt-1 text-xs text-white/40">450 kcal • P 25g • C 55g • F 13g</p>
                  </div>
                </div>
              </div>

              <div className="glass flex-1 rounded-3xl p-6">
                <p className="text-xs font-semibold uppercase tracking-wide text-brand-400">
                  Workout Plan Preview
                </p>
                <p className="mt-1 text-sm font-semibold text-white">Day 1 — Chest & Triceps</p>
                <div className="mt-4 space-y-2.5">
                  {[
                    ["Bench Press", "4 x 12"],
                    ["Incline Dumbbell Press", "4 x 12"],
                    ["Push Ups", "3 x 15"],
                    ["Tricep Pushdown", "3 x 15"],
                  ].map(([name, sets]) => (
                    <div key={name} className="flex items-center justify-between text-sm">
                      <span className="text-white/60">{name}</span>
                      <span className="font-medium text-white">{sets}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          {/* Dashboard */}
          <Reveal direction="right" delay={240}>
            <div className="glass flex h-full flex-col rounded-3xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-white">Dashboard</p>
                  <p className="text-xs text-white/40">Welcome back, Rahul 👋</p>
                </div>
                <span className="rounded-full bg-brand-400/10 px-3 py-1 text-xs font-semibold text-brand-400">
                  🔥 12 Day Streak
                </span>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-white/8 bg-black/30 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-white/40">
                    <Flame className="h-3.5 w-3.5 text-orange-400" /> Calories
                  </div>
                  <p className="mt-1 text-sm font-bold text-white">1280 / 2100</p>
                  <div className="mt-2 h-1.5 rounded-full bg-white/10">
                    <div className="h-1.5 w-[61%] rounded-full bg-orange-400" />
                  </div>
                </div>
                <div className="rounded-2xl border border-white/8 bg-black/30 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-white/40">
                    <Droplets className="h-3.5 w-3.5 text-sky-400" /> Water
                  </div>
                  <p className="mt-1 text-sm font-bold text-white">2.1 / 3.2 L</p>
                  <div className="mt-2 h-1.5 rounded-full bg-white/10">
                    <div className="h-1.5 w-[65%] rounded-full bg-sky-400" />
                  </div>
                </div>
              </div>

              <div className="mt-5 flex-1 space-y-3">
                {todaysPlan.map((item) => (
                  <div key={item.time} className="flex items-center gap-3 text-sm">
                    <span className="w-16 shrink-0 text-xs text-white/35">{item.time}</span>
                    <item.icon className="h-4 w-4 shrink-0 text-brand-400" />
                    <span className="text-white/70">{item.title}</span>
                  </div>
                ))}
              </div>

              <div className="mt-5 flex items-center gap-4 rounded-2xl border border-white/8 bg-black/30 p-4">
                <div
                  className="relative grid h-16 w-16 shrink-0 place-items-center rounded-full"
                  style={{
                    background: "conic-gradient(#7ef542 0% 70%, rgba(255,255,255,0.08) 70% 100%)",
                  }}
                >
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-[#0a0b0d] text-xs font-bold text-white">
                    70%
                  </div>
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Daily Goal</p>
                  <p className="text-xs text-white/40">You&apos;re doing great! Keep it up 💪</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Reminders strip */}
        <Reveal delay={320}>
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
            <div className="glass rounded-3xl p-6">
              <div className="flex items-center gap-2">
                <Footprints className="h-4 w-4 text-brand-400" />
                <p className="text-sm font-semibold text-white">Smart Email Reminders</p>
              </div>
              <p className="mt-1 text-xs text-white/40">
                Reminders for meals, workouts & water based on your daily schedule.
              </p>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  ["07:00 AM", "Workout Reminder"],
                  ["08:30 AM", "Breakfast Reminder"],
                  ["01:00 PM", "Lunch Reminder"],
                  ["05:30 PM", "Water Reminder"],
                ].map(([time, title]) => (
                  <div key={title} className="rounded-xl border border-white/8 bg-black/30 p-3">
                    <p className="text-[11px] text-brand-400">{time}</p>
                    <p className="mt-1 text-xs text-white/60">{title}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass flex flex-col justify-center gap-3 rounded-3xl p-6">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-400 text-black">
                <Mail className="h-5 w-5" />
              </span>
              <p className="text-sm font-semibold text-white">Your Meal Plan Reminder</p>
              <p className="text-xs leading-relaxed text-white/40">
                &ldquo;Hi Rahul, it&apos;s time for your lunch — Grilled Chicken, Brown Rice &
                Salad is waiting for you!&rdquo;
              </p>
              <p className="text-xs text-white/30">— FitNova Team</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
