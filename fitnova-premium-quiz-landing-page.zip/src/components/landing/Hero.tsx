"use client";

import Image from "next/image";
import { ArrowRight, CalendarDays, ClipboardList, LineChart, Salad, Bell, Star } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const quickFeatures = [
  { icon: ClipboardList, label: "Personalized Plan" },
  { icon: Salad, label: "Meal Plan" },
  { icon: CalendarDays, label: "Workout Plan" },
  { icon: LineChart, label: "Track Progress" },
  { icon: Bell, label: "Smart Reminders" },
];

const statCards = [
  { label: "BMI", value: "22.4", sub: "Normal", trend: [4, 7, 5, 9, 8, 11] },
  { label: "Daily Calories", value: "2,100", sub: "kcal", trend: [6, 5, 8, 7, 10, 9] },
  { label: "Protein", value: "142g", sub: "/ day", trend: [3, 6, 5, 8, 9, 12] },
  { label: "Water Intake", value: "3.2L", sub: "/ day", trend: [5, 4, 7, 6, 9, 10] },
];

function Sparkline({ points }: { points: number[] }) {
  const max = Math.max(...points);
  const w = 64;
  const h = 24;
  const step = w / (points.length - 1);
  const path = points
    .map((p, i) => `${i === 0 ? "M" : "L"}${i * step},${h - (p / max) * h}`)
    .join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <path d={path} fill="none" stroke="#7ef542" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-[#07080a] pb-20 pt-32 sm:pt-40">
      {/* Ambient background */}
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-40" />
      <div className="pointer-events-none absolute -left-40 top-10 h-96 w-96 animate-float-slow rounded-full bg-brand-500/20 blur-[110px]" />
      <div className="pointer-events-none absolute -right-32 top-40 h-80 w-80 animate-float rounded-full bg-emerald-400/10 blur-[100px]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#07080a] to-transparent" />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 gap-16 px-4 sm:px-6 lg:grid-cols-2 lg:items-center lg:px-8">
        {/* Copy */}
        <div>
          <Reveal>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-brand-300">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-400" />
              </span>
              Trusted by 50,000+ fitness enthusiasts
            </div>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="mt-6 text-[clamp(2.5rem,6vw,4rem)] font-extrabold leading-[1.05] tracking-tight text-white">
              Your Personalized
              <br />
              <span className="text-gradient animate-gradient bg-gradient-to-r from-brand-200 via-brand-400 to-emerald-500 bg-[length:200%_auto]">
                Fitness Coach
              </span>
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/60">
              Get a custom workout plan, meal plan, and daily guidance designed just for your
              body and your goals — powered by a smart 2-minute quiz.
            </p>
          </Reveal>

          <Reveal delay={220}>
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-4">
              {quickFeatures.map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center gap-2 text-center">
                  <span className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-brand-300 transition-all duration-300 hover:-translate-y-1 hover:border-brand-400/40 hover:bg-brand-400/10">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="w-16 text-[11px] leading-tight text-white/50">{label}</span>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={280}>
            <div className="mt-9 flex flex-col gap-4 sm:flex-row sm:items-center">
              <a
                href="/quiz"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-brand-400 px-7 py-4 text-base font-semibold text-black shadow-[0_0_35px_rgba(126,245,66,0.35)] transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_50px_rgba(126,245,66,0.55)] active:scale-95"
              >
                Start Free Quiz
                <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <span className="text-sm text-white/40">Takes 2-3 minutes only</span>
            </div>
          </Reveal>

          <Reveal delay={340}>
            <div className="mt-8 flex items-center gap-3">
              <div className="flex -space-x-3">
                {[
                  "https://images.pexels.com/photos/6102841/pexels-photo-6102841.jpeg?auto=compress&cs=tinysrgb&h=80&w=80",
                  "https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&h=80&w=80",
                  "https://images.pexels.com/photos/20085710/pexels-photo-20085710.jpeg?auto=compress&cs=tinysrgb&h=80&w=80",
                ].map((src, i) => (
                  <Image
                    key={src}
                    src={src}
                    alt="FitNova member"
                    width={36}
                    height={36}
                    className="h-9 w-9 rounded-full border-2 border-[#07080a] object-cover"
                    style={{ zIndex: 3 - i }}
                  />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-0.5 text-brand-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-3.5 w-3.5 fill-current" />
                  ))}
                </div>
                <p className="text-xs text-white/40">Trusted by 50,000+ Fitness Enthusiasts</p>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Visual */}
        <div className="relative">
          <Reveal direction="scale" delay={200}>
            <div className="relative mx-auto aspect-[4/5] max-w-md">
              <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-b from-brand-500/25 via-transparent to-transparent blur-2xl" />
              <div className="relative h-full w-full overflow-hidden rounded-[2.5rem] border border-white/10">
                <Image
                  src="/images/hero-athlete.png"
                  alt="Fit athlete training with FitNova"
                  fill
                  priority
                  sizes="(max-width: 1024px) 90vw, 480px"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/10" />
              </div>

              {/* Radial rings */}
              <div className="pointer-events-none absolute left-1/2 top-1/2 h-[60%] w-[60%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-brand-400/20" />
            </div>
          </Reveal>

          {/* Floating stat cards */}
          <div className="absolute -right-2 top-2 hidden w-44 flex-col gap-3 sm:-right-6 sm:flex lg:-right-10">
            {statCards.map((card, i) => (
              <Reveal key={card.label} direction="right" delay={400 + i * 120}>
                <div
                  className="animate-float glass rounded-2xl p-3.5 shadow-[0_10px_40px_rgba(0,0,0,0.4)]"
                  style={{ animationDelay: `${i * 0.6}s` }}
                >
                  <p className="text-[11px] text-white/45">{card.label}</p>
                  <div className="mt-1 flex items-end justify-between gap-2">
                    <div>
                      <p className="text-lg font-bold text-white">{card.value}</p>
                      <p className="text-[10px] text-brand-400">{card.sub}</p>
                    </div>
                    <Sparkline points={card.trend} />
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
