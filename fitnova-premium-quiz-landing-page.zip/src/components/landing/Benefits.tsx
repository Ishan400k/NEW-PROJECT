import Image from "next/image";
import { Check } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const benefits = [
  {
    title: "Built around your body, not a generic template",
    desc: "Every plan is generated from your gender, age, height, weight, goal and activity level.",
  },
  {
    title: "Science-backed nutrition targets",
    desc: "Calorie & macro targets calculated using proven formulas (Mifflin-St Jeor) used by professional coaches.",
  },
  {
    title: "Stay consistent with daily guidance",
    desc: "Smart reminders and a live dashboard keep you accountable every single day.",
  },
  {
    title: "See real, measurable progress",
    desc: "Track weight, calories, water, and workouts with visual trends that keep you motivated.",
  },
];

export function Benefits() {
  return (
    <section className="relative bg-[#0a0b0d] py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-2">
          <Reveal direction="left">
            <div className="relative mx-auto aspect-square max-w-md">
              <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-tr from-brand-500/20 to-transparent blur-3xl" />
              <div className="relative h-full w-full overflow-hidden rounded-[2.5rem] border border-white/10">
                <Image
                  src="/images/hero-athlete.png"
                  alt="FitNova member training"
                  fill
                  sizes="(max-width: 1024px) 90vw, 480px"
                  className="object-cover object-top"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>
              <div className="glass absolute -bottom-6 -right-4 w-48 rounded-2xl p-4 shadow-xl sm:-right-8">
                <p className="text-xs text-white/40">Weight Progress</p>
                <p className="mt-1 text-xl font-bold text-brand-400">−6.4 kg</p>
                <p className="text-[11px] text-white/40">in the last 8 weeks</p>
              </div>
            </div>
          </Reveal>

          <div>
            <Reveal>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
                Why FitNova
              </p>
              <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
                A coach that adapts to <span className="text-gradient">you.</span>
              </h2>
            </Reveal>

            <div className="mt-8 space-y-6">
              {benefits.map((b, i) => (
                <Reveal key={b.title} delay={i * 100}>
                  <div className="group flex gap-4">
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-400/15 text-brand-400 transition-transform duration-300 group-hover:scale-110">
                      <Check className="h-4 w-4" strokeWidth={3} />
                    </span>
                    <div>
                      <h3 className="font-semibold text-white">{b.title}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-white/50">{b.desc}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
