import { ClipboardList, Salad, Dumbbell, LineChart, BellRing, Users } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const features = [
  {
    icon: ClipboardList,
    title: "Personalized Plan",
    desc: "A workout & nutrition blueprint built entirely around your body stats, goals and lifestyle.",
  },
  {
    icon: Salad,
    title: "Meal Plan",
    desc: "Daily meal breakdowns with macros calculated to match your calorie targets exactly.",
  },
  {
    icon: Dumbbell,
    title: "Workout Plan",
    desc: "Structured strength & conditioning sessions that progress automatically as you improve.",
  },
  {
    icon: LineChart,
    title: "Track Progress",
    desc: "Visualize weight, calories, water and workouts with a beautiful real-time dashboard.",
  },
  {
    icon: BellRing,
    title: "Smart Reminders",
    desc: "Timely nudges for meals, water and workouts so you never fall off track.",
  },
  {
    icon: Users,
    title: "Coach Support",
    desc: "Access certified coaches for form checks, plan tweaks and accountability check-ins.",
  },
];

export function Features() {
  return (
    <section id="features" className="relative bg-[#0a0b0d] py-24">
      <div className="pointer-events-none absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-brand-500/10 blur-[120px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
            Everything you need
          </p>
          <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            One app. Your entire <span className="text-gradient">transformation.</span>
          </h2>
          <p className="mt-4 text-white/55">
            FitNova combines science-backed programming with an experience that actually keeps
            you consistent.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, i) => (
            <Reveal key={feature.title} delay={i * 90} direction="scale">
              <div className="group relative h-full overflow-hidden rounded-3xl border border-white/8 bg-white/[0.02] p-7 transition-all duration-400 hover:-translate-y-1.5 hover:border-brand-400/30 hover:bg-white/[0.04]">
                <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-brand-400/0 blur-2xl transition-all duration-500 group-hover:bg-brand-400/20" />
                <div className="relative grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-brand-400 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="relative mt-5 text-lg font-bold text-white">{feature.title}</h3>
                <p className="relative mt-2 text-sm leading-relaxed text-white/50">{feature.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
