import Image from "next/image";
import { Star, Quote } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

const testimonials = [
  {
    name: "Ananya Rao",
    role: "Lost 8kg in 10 weeks",
    avatar: "https://images.pexels.com/photos/29132010/pexels-photo-29132010.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "The quiz took two minutes but the plan felt like it was made by a personal trainer who actually knew me. The reminders kept me consistent for the first time ever.",
  },
  {
    name: "Rahul Mehta",
    role: "Gained 5kg lean muscle",
    avatar: "https://images.pexels.com/photos/6102841/pexels-photo-6102841.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "I've tried three other apps before. FitNova's macro targets and workout progression are the only ones that actually matched my recomposition goals.",
  },
  {
    name: "Sneha Kapoor",
    role: "Improved stamina & energy",
    avatar: "https://images.pexels.com/photos/12231911/pexels-photo-12231911.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "For ₹40 I expected a basic template. Instead I got a full dashboard, meal plan and daily check-ins. Genuinely worth every rupee.",
  },
  {
    name: "Vikram Singh",
    role: "Down 2 BMI points",
    avatar: "https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "The dashboard makes it addictive in a good way — I check my streak every morning and it keeps me from skipping workouts.",
  },
  {
    name: "Priya Nair",
    role: "Building a sustainable habit",
    avatar: "https://images.pexels.com/photos/38366748/pexels-photo-38366748.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "Simple, elegant, and it doesn't overwhelm me with a thousand settings. It just tells me what to eat and do, every day.",
  },
  {
    name: "Arjun Verma",
    role: "Marathon training",
    avatar: "https://images.pexels.com/photos/20085710/pexels-photo-20085710.jpeg?auto=compress&cs=tinysrgb&h=120&w=120",
    quote:
      "The activity-based calorie recalculation is spot on. My energy levels during long runs have improved massively.",
  },
];

export function Testimonials() {
  return (
    <section className="relative overflow-hidden bg-[#07080a] py-24">
      <div className="pointer-events-none absolute right-0 top-1/3 h-72 w-72 rounded-full bg-brand-500/10 blur-[110px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-400">
            Real results
          </p>
          <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            Loved by <span className="text-gradient">thousands</span> of members.
          </h2>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 80} direction="scale">
              <div className="group h-full rounded-3xl border border-white/8 bg-white/[0.02] p-6 transition-all duration-400 hover:-translate-y-1.5 hover:border-brand-400/25 hover:bg-white/[0.04]">
                <Quote className="h-6 w-6 text-brand-400/50" />
                <p className="mt-4 text-sm leading-relaxed text-white/70">&ldquo;{t.quote}&rdquo;</p>
                <div className="mt-6 flex items-center gap-3">
                  <Image
                    src={t.avatar}
                    alt={t.name}
                    width={44}
                    height={44}
                    className="h-11 w-11 rounded-full object-cover"
                  />
                  <div>
                    <p className="text-sm font-semibold text-white">{t.name}</p>
                    <p className="text-xs text-white/40">{t.role}</p>
                  </div>
                  <div className="ml-auto flex gap-0.5 text-brand-400">
                    {Array.from({ length: 5 }).map((_, idx) => (
                      <Star key={idx} className="h-3 w-3 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
