import { Reveal } from "@/components/ui/Reveal";
import { AnimatedCounter } from "@/components/ui/AnimatedCounter";

const stats = [
  { value: 50000, suffix: "+", label: "Active Members" },
  { value: 25, suffix: "+", label: "Quiz Data Points" },
  { value: 4.9, suffix: "/5", decimals: 1, label: "Average Rating" },
  { value: 92, suffix: "%", label: "Reached Their Goal" },
];

const logos = [
  "MensHealth",
  "ShapeIndia",
  "FitTech",
  "WellnessDaily",
  "PulseMag",
  "IronWire",
];

export function SocialProof() {
  return (
    <section className="relative border-y border-white/5 bg-[#0a0b0d] py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="bg-gradient-to-b from-white to-white/60 bg-clip-text text-3xl font-extrabold text-transparent sm:text-4xl">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} decimals={stat.decimals ?? 0} />
                </p>
                <p className="mt-1 text-xs text-white/45 sm:text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="mt-12 overflow-hidden">
            <p className="mb-5 text-center text-xs uppercase tracking-[0.2em] text-white/30">
              As featured in
            </p>
            <div className="relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
              <div className="flex min-w-full shrink-0 animate-marquee items-center justify-around gap-16">
                {[...logos, ...logos].map((logo, i) => (
                  <span
                    key={`${logo}-${i}`}
                    className="whitespace-nowrap text-lg font-bold tracking-tight text-white/25"
                  >
                    {logo}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
