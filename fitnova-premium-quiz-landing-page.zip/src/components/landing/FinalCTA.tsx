import { ArrowRight, Sparkles } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";

export function FinalCTA() {
  return (
    <section className="relative overflow-hidden bg-[#07080a] px-4 py-24 sm:px-6 lg:px-8">
      <Reveal direction="scale">
        <div className="relative mx-auto max-w-5xl overflow-hidden rounded-[2.5rem] border border-white/10 bg-gradient-to-br from-brand-600/25 via-[#0c0e0c] to-emerald-900/20 p-10 text-center sm:p-16">
          <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 animate-float-slow rounded-full bg-brand-400/25 blur-[100px]" />
          <div className="pointer-events-none absolute -bottom-20 -right-10 h-72 w-72 animate-float rounded-full bg-emerald-400/15 blur-[100px]" />

          <div className="relative">
            <span className="mx-auto inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-medium text-brand-300">
              <Sparkles className="h-3.5 w-3.5" />
              Join 50,000+ transforming their fitness
            </span>
            <h2 className="mx-auto mt-6 max-w-2xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
              Your transformation starts with a <span className="text-gradient">2-minute quiz.</span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-white/60">
              Get your personalized plan today for just ₹40. No guesswork, no generic templates —
              just a plan built for you.
            </p>
            <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <a
                href="/quiz"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-brand-400 px-8 py-4 text-base font-semibold text-black shadow-[0_0_40px_rgba(126,245,66,0.4)] transition-all duration-300 hover:scale-[1.04] hover:shadow-[0_0_60px_rgba(126,245,66,0.6)] active:scale-95"
              >
                Start Free Quiz
                <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <span className="text-sm text-white/40">₹40 today · ₹129/month after</span>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
