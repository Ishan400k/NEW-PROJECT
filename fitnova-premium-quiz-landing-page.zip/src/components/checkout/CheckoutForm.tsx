"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2, Lock, ShieldCheck, BadgeCheck, ArrowRight, Zap } from "lucide-react";

export function CheckoutForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const quizId = searchParams.get("quizId");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, quizResponseId: quizId }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error ?? "Something went wrong. Please try again.");
      }
      router.push(`/checkout/success?order=${data.orderId}&name=${encodeURIComponent(name)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_1.1fr] lg:gap-14 lg:py-20">
      {/* Summary */}
      <div>
        <a href="/" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-700 text-black">
            <Zap className="h-5 w-5" strokeWidth={2.5} />
          </span>
          <span className="text-lg font-bold text-white">FitNova</span>
        </a>

        <h1 className="mt-8 text-2xl font-extrabold text-white sm:text-3xl">
          Complete your subscription
        </h1>
        <p className="mt-2 text-sm text-white/50">
          You're one step away from your personalized fitness plan.
        </p>

        <div className="glass mt-8 rounded-3xl p-6">
          <div className="flex items-center justify-between border-b border-white/8 pb-4">
            <span className="text-sm text-white/60">FitNova Personalized Plan</span>
            <span className="rounded-full bg-brand-400/15 px-3 py-1 text-xs font-semibold text-brand-400">
              Monthly
            </span>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm text-white/60">First month (today)</span>
            <span className="text-xl font-extrabold text-brand-400">₹40</span>
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-sm text-white/60">From 2nd month</span>
            <span className="text-sm font-semibold text-white">₹129 / month</span>
          </div>
          <div className="mt-5 space-y-2 border-t border-white/8 pt-4 text-xs text-white/40">
            <p>✓ Full personalized workout & meal plan</p>
            <p>✓ Live progress dashboard & smart reminders</p>
            <p>✓ Cancel anytime, no questions asked</p>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-white/40">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-brand-400" /> Cancel anytime
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Lock className="h-4 w-4 text-brand-400" /> Secure checkout
          </span>
          <span className="inline-flex items-center gap-1.5">
            <BadgeCheck className="h-4 w-4 text-brand-400" /> No hidden charges
          </span>
        </div>
      </div>

      {/* Form */}
      <div className="glass rounded-3xl p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          <div>
            <label htmlFor="name" className="text-xs font-medium text-white/50">
              Full name
            </label>
            <input
              id="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Rahul Sharma"
              className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors placeholder:text-white/25 focus:border-brand-400/60"
            />
          </div>
          <div>
            <label htmlFor="email" className="text-xs font-medium text-white/50">
              Email address
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors placeholder:text-white/25 focus:border-brand-400/60"
            />
          </div>
          <div>
            <label htmlFor="phone" className="text-xs font-medium text-white/50">
              Phone number
            </label>
            <input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 98765 43210"
              className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors placeholder:text-white/25 focus:border-brand-400/60"
            />
          </div>

          <div className="mt-1 rounded-xl border border-white/10 bg-white/[0.02] p-4">
            <p className="text-xs font-medium text-white/50">Payment method</p>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px] text-white/40">
              <div className="rounded-lg border border-brand-400/40 bg-brand-400/10 py-2.5 font-semibold text-brand-300">
                UPI
              </div>
              <div className="rounded-lg border border-white/10 py-2.5">Card</div>
              <div className="rounded-lg border border-white/10 py-2.5">Netbanking</div>
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-white/30">
              Demo checkout — no real payment is processed. In production this connects to a
              secure payment gateway (UPI / Cards / Netbanking).
            </p>
          </div>

          {error && (
            <p className="rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-400">{error}</p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="group mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-brand-400 py-4 text-base font-semibold text-black shadow-[0_0_35px_rgba(126,245,66,0.35)] transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_50px_rgba(126,245,66,0.55)] active:scale-95 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Processing payment...
              </>
            ) : (
              <>
                <Lock className="h-4 w-4" />
                Pay ₹40 & Get Started
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </>
            )}
          </button>
          <p className="text-center text-[11px] text-white/30">
            By continuing you agree that ₹40 will be charged today and ₹129 will be auto-charged
            every month after, until you cancel.
          </p>
        </form>
      </div>
    </div>
  );
}
