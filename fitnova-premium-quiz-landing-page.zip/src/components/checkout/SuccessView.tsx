"use client";

import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowRight, Zap, CalendarClock } from "lucide-react";

export function SuccessView() {
  const searchParams = useSearchParams();
  const order = searchParams.get("order") ?? "FN-DEMO";
  const name = searchParams.get("name") ?? "there";

  return (
    <div className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center px-4 py-12 text-center sm:px-6">
      <a href="/" className="mb-10 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-700 text-black">
          <Zap className="h-5 w-5" strokeWidth={2.5} />
        </span>
        <span className="text-lg font-bold text-white">FitNova</span>
      </a>

      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 14 }}
        className="grid h-20 w-20 place-items-center rounded-full bg-brand-400/15 text-brand-400"
      >
        <CheckCircle2 className="h-10 w-10" />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.5 }}
        className="mt-6 text-3xl font-extrabold text-white"
      >
        Welcome to FitNova, {name}! 🎉
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25, duration: 0.5 }}
        className="mt-3 max-w-md text-sm text-white/55"
      >
        Your payment of ₹40 was successful and your personalized plan is being prepared. A
        confirmation has been sent to your email.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.5 }}
        className="glass mt-8 w-full rounded-3xl p-6 text-left"
      >
        <div className="flex items-center justify-between border-b border-white/8 pb-4">
          <span className="text-xs text-white/40">Order ID</span>
          <span className="font-mono text-sm text-white">{order}</span>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-white/40">Amount charged today</span>
          <span className="text-sm font-semibold text-brand-400">₹40</span>
        </div>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-white/40">Next billing</span>
          <span className="inline-flex items-center gap-1.5 text-sm text-white">
            <CalendarClock className="h-3.5 w-3.5 text-white/40" />
            ₹129 / month
          </span>
        </div>
      </motion.div>

      <motion.a
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45, duration: 0.5 }}
        href="/"
        className="group mt-8 inline-flex items-center gap-2 rounded-full bg-brand-400 px-7 py-3.5 text-sm font-semibold text-black shadow-[0_0_30px_rgba(126,245,66,0.35)] transition-all duration-300 hover:scale-105 active:scale-95"
      >
        Back to Home
        <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
      </motion.a>
    </div>
  );
}
